package com.myapplicationdev.android.p10_gettingmylocationsenhanced;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class CheckRecord extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
